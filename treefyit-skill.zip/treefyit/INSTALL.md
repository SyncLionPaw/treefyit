# TreefyIt Skill Installation

This skill is self-contained. Users do not need to clone the full TreefyIt repo.

## What to distribute

Distribute the whole `treefyit/` skill directory:

```text
treefyit/
├── SKILL.md
├── INSTALL.md
├── install.py
├── scripts/
│   ├── treefyit_tool.py
│   └── treefyit_sdk.py
└── references/
    └── tool-contract.md
```

## How users install it

Place that directory into the target agent's skill directory so the final layout becomes:

```text
<skills-root>/treefyit/
```

In this workspace, the project-local skill root is:

```text
.trae/skills/
```

## Runtime requirement

The skill only requires:

- Python 3
- network reachability to a TreefyIt service

It does not require a local TreefyIt source checkout.

## Service configuration

Users can point the skill at any TreefyIt deployment:

```bash
export TREEFYIT_BASE_URL=https://treefyit.example.com
uv run python scripts/treefyit_tool.py overview_forest
```

Or pass the address per call:

```bash
uv run python scripts/treefyit_tool.py --base-url https://treefyit.example.com overview_forest
```

Priority:

```text
--base-url > TREEFYIT_BASE_URL > treefyit.config.json > http://127.0.0.1:8765
```

## Interactive setup

The easiest install path after copying the skill folder is:

```bash
cd treefyit
uv run python install.py
```

The installer asks the user to choose:

- `local` or `cloud`
- the target `base_url`
- the `api_key` for cloud mode

Then it writes:

```text
treefyit.config.json
```

The runtime also supports:

- `TREEFYIT_API_KEY`
- `--api-key <key>`

## Suggested distribution forms

- zip or tarball containing the `treefyit/` directory
- a standalone repository that contains only this skill
- a future package format once the target agent runtime defines one
