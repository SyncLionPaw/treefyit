# TreefyIt Skill Tool Contract

This document defines the exact execution contract used by the TreefyIt skill.

## Wrapper Script

Path:

```text
scripts/treefyit_tool.py
```

Interactive installer:

```text
install.py
```

Bundled SDK:

```text
scripts/treefyit_sdk.py
```

Default service base URL:

```text
http://127.0.0.1:8765
```

Override options:

```text
1. --base-url <url>
2. TREEFYIT_BASE_URL=<url>
3. treefyit.config.json
```

Priority:

```text
--base-url > TREEFYIT_BASE_URL > treefyit.config.json > http://127.0.0.1:8765
```

Every command prints JSON to stdout.

API key override options:

```text
1. --api-key <key>
2. TREEFYIT_API_KEY=<key>
3. treefyit.config.json
```

## Commands

### build_knowledge

```bash
uv run python scripts/treefyit_tool.py build_knowledge --file /absolute/path/to/file.pdf --summarize
```

Arguments:

- `--file`: required absolute or relative file path
- `--summarize` / `--no-summarize`: optional, default summarize enabled
- `--base-url`: optional
- `--api-key`: optional

### overview_forest

```bash
uv run python scripts/treefyit_tool.py overview_forest
TREEFYIT_BASE_URL=https://treefyit.example.com uv run python scripts/treefyit_tool.py overview_forest
uv run python scripts/treefyit_tool.py --base-url https://treefyit.example.com --api-key sk-xxx overview_forest
```

### search_trees

```bash
uv run python scripts/treefyit_tool.py search_trees --query "rag chunking" --limit 5
```

Arguments:

- `--query`: required
- `--limit`: optional, default `5`

### overview

```bash
uv run python scripts/treefyit_tool.py overview --tree-id 1902897a3b4c0d1e
```

### children

```bash
uv run python scripts/treefyit_tool.py children --tree-id 1902897a3b4c0d1e --node-id 0.1
```

### inspect

```bash
uv run python scripts/treefyit_tool.py inspect --tree-id 1902897a3b4c0d1e --node-id 0.1.2
```

## Failure Modes

- If the service is unreachable or returns a non-2xx status, the script exits non-zero.
- If `build_knowledge` receives a missing file path, the script exits non-zero.
- The skill does not depend on a local TreefyIt source checkout. It only depends on network reachability to the configured service.

## Interactive install flow

```bash
uv run python install.py
```

This writes `treefyit.config.json` with:

```json
{
  "mode": "local",
  "base_url": "http://127.0.0.1:8765",
  "api_key": ""
}
```

## Usage Pattern

Recommended sequence:

```text
1. build_knowledge(file) if a new document must be loaded
2. overview_forest() or search_trees(query)
3. overview(tree_id)
4. children(tree_id, node_id)
5. inspect(tree_id, node_id)
```
