---
name: "treefyit"
description: "Builds and inspects TreefyIt knowledge bases from local documents. Invoke when the user wants structured document retrieval, knowledge-base navigation, or grounded answers from TreefyIt."
---

# TreefyIt

Use this skill when the user wants to work with documents through TreefyIt's structured knowledge-base service instead of reading raw files directly.

This skill is for:

- building a knowledge base from a local file
- listing all available knowledge bases
- selecting the right knowledge base for a topic
- navigating a knowledge base by structure before reading full text
- answering questions with grounded evidence from TreefyIt

This skill is not for:

- generic web search
- ad hoc file parsing outside TreefyIt
- free-form chat when no TreefyIt service is available

## Preconditions

This skill contains its own HTTP SDK and can talk to any reachable TreefyIt service.

TreefyIt service defaults to `http://127.0.0.1:8765`.

You can point the skill to another service address in either of these ways:

1. pass `--base-url <url>` to the wrapper script
2. set environment variable `TREEFYIT_BASE_URL=<url>`
3. write config file `treefyit.config.json` by running `python install.py`

Priority is:

```text
--base-url > TREEFYIT_BASE_URL > treefyit.config.json > http://127.0.0.1:8765
```

If you are using a local TreefyIt service and it is not running, start that local service in the way your environment provides.

## Installation

This skill is designed to be self-contained.

To install it into another agent environment, copy the entire `treefyit/` directory into that environment's skill directory so the final layout is:

```text
<skills-root>/
└── treefyit/
    ├── SKILL.md
    ├── scripts/
    │   ├── treefyit_tool.py
    │   └── treefyit_sdk.py
    └── references/
        └── tool-contract.md
```

In this workspace, the project-level install location is:

```text
.trae/skills/treefyit/
```

After installation, point the skill to a reachable TreefyIt service by either:

- passing `--base-url <url>`
- setting `TREEFYIT_BASE_URL=<url>`
- running `python install.py` to generate `treefyit.config.json`

For cloud deployments, configure an API key by either:

- passing `--api-key <key>`
- setting `TREEFYIT_API_KEY=<key>`
- storing `api_key` in `treefyit.config.json`

## Tool Surface

This skill exposes the following stable capability surface:

1. `build_knowledge(file, summarize=true)`
2. `overview_forest()`
3. `search_trees(query, limit=5)`
4. `overview(tree_id)`
5. `children(tree_id, node_id="0")`
6. `inspect(tree_id, node_id="0")`

The intended retrieval path is:

```text
overview_forest / search_trees -> overview -> children -> inspect
```

Follow that order unless the user explicitly points to a known `tree_id` and `node_id`.

## How To Execute

Use the bundled CLI wrapper:

`scripts/treefyit_tool.py`

The wrapper uses the bundled SDK:

`scripts/treefyit_sdk.py`

The package also includes an interactive installer:

`install.py`

Examples:

```bash
uv run python scripts/treefyit_tool.py overview_forest
uv run python scripts/treefyit_tool.py --base-url https://treefyit.example.com overview_forest
uv run python scripts/treefyit_tool.py --base-url https://treefyit.example.com --api-key sk-xxx overview_forest
uv run python scripts/treefyit_tool.py search_trees --query "deepseek adapter"
uv run python scripts/treefyit_tool.py overview --tree-id 1902897a3b4c0d1e
uv run python scripts/treefyit_tool.py children --tree-id 1902897a3b4c0d1e --node-id 0.1
uv run python scripts/treefyit_tool.py inspect --tree-id 1902897a3b4c0d1e --node-id 0.1.2
uv run python scripts/treefyit_tool.py build_knowledge --file /absolute/path/to/file.pdf --summarize
uv run python install.py
```

## Operating Rules

1. Prefer `search_trees` when the user gives a topic but not a knowledge-base id.
2. Prefer `overview_forest` when the user asks what knowledge bases are available.
3. Prefer `overview` before `inspect`.
4. Prefer `children` to narrow the branch before loading full node text.
5. Use `inspect` only for nodes likely to contain answer evidence.
6. Treat `build.id == tree_id`.
7. Treat `node_id` as the TreefyIt path string, for example `0`, `0.1`, `0.1.2`.
8. `build_knowledge` may return a cached result when the uploaded file bytes match an existing build.
9. For remote deployments, prefer setting `TREEFYIT_BASE_URL` once per environment instead of repeating `--base-url` in every command.
10. The skill must remain transport-oriented: call the configured TreefyIt service over HTTP instead of importing logic from a local TreefyIt repo.
11. For distributable installs, prefer `install.py` so users can choose local or cloud mode interactively and store `base_url` and `api_key` in `treefyit.config.json`.

## Response Guidelines

- When using TreefyIt results to answer the user, cite the selected knowledge base and relevant node titles when useful.
- If the tree is unknown, recover with `overview_forest` or `search_trees`.
- If the service is unavailable, say so explicitly instead of guessing.
- Do not expose internal implementation detail unless the user asks for it.

## References

For the exact CLI contract and example commands, read:

- `references/tool-contract.md`
