from __future__ import annotations

import json
from pathlib import Path

from scripts.treefyit_sdk import CONFIG_FILE_NAME, DEFAULT_BASE_URL


DEFAULT_CLOUD_BASE_URL = "https://api.treefyit.example.com"


def skill_root() -> Path:
    return Path(__file__).resolve().parent


def config_path() -> Path:
    return skill_root() / CONFIG_FILE_NAME


def prompt(text: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{text}{suffix}: ").strip()
    if value:
        return value
    return default or ""


def choose_mode() -> str:
    print("Choose TreefyIt connection mode:")
    print("1. local")
    print("2. cloud")
    choice = input("Enter 1 or 2 [1]: ").strip() or "1"
    if choice == "2":
        return "cloud"
    return "local"


def build_config() -> dict[str, str]:
    mode = choose_mode()
    if mode == "local":
        base_url = prompt("Local TreefyIt base URL", DEFAULT_BASE_URL)
        api_key = prompt("API key (optional for local)", "")
    else:
        base_url = prompt("Cloud TreefyIt base URL", DEFAULT_CLOUD_BASE_URL)
        api_key = ""
        while not api_key:
            api_key = prompt("Cloud API key", "")
            if not api_key:
                print("Cloud mode requires an API key.")

    return {
        "mode": mode,
        "base_url": base_url,
        "api_key": api_key,
    }


def write_config(config: dict[str, str]) -> None:
    path = config_path()
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Written config: {path}")


def print_next_steps(config: dict[str, str]) -> None:
    print("")
    print("TreefyIt skill is configured.")
    print(f"Mode: {config['mode']}")
    print(f"Base URL: {config['base_url']}")
    print("")
    print("Next command example:")
    print("  uv run python scripts/treefyit_tool.py overview_forest")


def main() -> None:
    print("TreefyIt skill installer")
    print(f"Skill root: {skill_root()}")
    print("")
    config = build_config()
    write_config(config)
    print_next_steps(config)


if __name__ == "__main__":
    main()
