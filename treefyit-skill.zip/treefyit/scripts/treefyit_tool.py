from __future__ import annotations

import argparse
import json
import os

from treefyit_sdk import (
    API_KEY_ENV,
    BASE_URL_ENV,
    DEFAULT_BASE_URL,
    TreefyitClient,
    default_config_path,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="TreefyIt skill CLI wrapper")
    parser.add_argument(
        "--base-url",
        default=None,
        help=(
            "TreefyIt service base URL. "
            f"Defaults to ${BASE_URL_ENV} or {DEFAULT_BASE_URL}."
        ),
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help=(
            "TreefyIt API key. "
            f"Defaults to ${API_KEY_ENV} or {default_config_path().name}."
        ),
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    build_parser = subparsers.add_parser("build_knowledge")
    build_parser.add_argument("--file", required=True, help="Path to local file")
    build_parser.add_argument(
        "--summarize",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Whether to summarize nodes during build",
    )

    subparsers.add_parser("overview_forest")

    search_parser = subparsers.add_parser("search_trees")
    search_parser.add_argument("--query", required=True, help="Search query")
    search_parser.add_argument("--limit", type=int, default=5, help="Max result count")

    overview_parser = subparsers.add_parser("overview")
    overview_parser.add_argument("--tree-id", required=True, help="Tree identifier")

    children_parser = subparsers.add_parser("children")
    children_parser.add_argument("--tree-id", required=True, help="Tree identifier")
    children_parser.add_argument("--node-id", default="0", help="Node identifier")

    inspect_parser = subparsers.add_parser("inspect")
    inspect_parser.add_argument("--tree-id", required=True, help="Tree identifier")
    inspect_parser.add_argument("--node-id", default="0", help="Node identifier")

    return parser


def run_command(args: argparse.Namespace):
    client = TreefyitClient(
        base_url=args.base_url,
        api_key=args.api_key,
    )

    if args.command == "build_knowledge":
        return client.build_knowledge(args.file, summarize=args.summarize)

    if args.command == "overview_forest":
        return client.overview_forest()

    if args.command == "search_trees":
        return client.search_trees(args.query, limit=args.limit)

    if args.command == "overview":
        return client.overview(args.tree_id)

    if args.command == "children":
        return client.children(args.tree_id, node_id=args.node_id)

    if args.command == "inspect":
        return client.inspect(args.tree_id, node_id=args.node_id)

    raise SystemExit(f"Unsupported command: {args.command}")


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    result = run_command(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
