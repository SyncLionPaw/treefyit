from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


DEFAULT_BASE_URL = "http://127.0.0.1:8765"
BASE_URL_ENV = "TREEFYIT_BASE_URL"
API_KEY_ENV = "TREEFYIT_API_KEY"
CONFIG_PATH_ENV = "TREEFYIT_CONFIG_PATH"
CONFIG_FILE_NAME = "treefyit.config.json"


class TreefyitToolError(RuntimeError):
    pass


def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def resolve_base_url(base_url: str | None) -> str:
    explicit = (base_url or "").strip()
    if explicit:
        return normalize_base_url(explicit)

    from_env = os.getenv(BASE_URL_ENV, "").strip()
    if from_env:
        return normalize_base_url(from_env)

    return DEFAULT_BASE_URL


def resolve_api_key(api_key: str | None) -> str | None:
    explicit = (api_key or "").strip()
    if explicit:
        return explicit

    from_env = os.getenv(API_KEY_ENV, "").strip()
    if from_env:
        return from_env

    config = load_config()
    from_config = str(config.get("api_key") or "").strip()
    if from_config:
        return from_config

    return None


def skill_root() -> Path:
    return Path(__file__).resolve().parents[1]


def default_config_path() -> Path:
    return skill_root() / CONFIG_FILE_NAME


def resolve_config_path() -> Path:
    explicit = os.getenv(CONFIG_PATH_ENV, "").strip()
    if explicit:
        return Path(explicit).expanduser()
    return default_config_path()


def load_config() -> dict[str, Any]:
    config_path = resolve_config_path()
    if not config_path.exists():
        return {}

    try:
        return json.loads(config_path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise TreefyitToolError(
            f"Invalid TreefyIt config JSON: {config_path}"
        ) from exc


def configured_base_url() -> str | None:
    config = load_config()
    value = str(config.get("base_url") or "").strip()
    return value or None


def resolved_base_url_from_all_sources(base_url: str | None) -> str:
    explicit = (base_url or "").strip()
    if explicit:
        return normalize_base_url(explicit)

    from_env = os.getenv(BASE_URL_ENV, "").strip()
    if from_env:
        return normalize_base_url(from_env)

    from_config = configured_base_url()
    if from_config:
        return normalize_base_url(from_config)

    return DEFAULT_BASE_URL


def parse_json_response(data: bytes) -> Any:
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError as exc:
        raise TreefyitToolError(
            f"TreefyIt returned non-JSON response: {data[:400].decode('utf-8', errors='replace')}"
        ) from exc


def request_json(
    method: str,
    url: str,
    *,
    timeout_sec: float,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    body: bytes | None = None,
    content_type: str | None = None,
) -> Any:
    final_url = url
    if params:
        query = urlencode(
            {key: value for key, value in params.items() if value is not None}
        )
        if query:
            final_url = f"{url}?{query}"

    request_headers = dict(headers or {})
    if content_type:
        request_headers["Content-Type"] = content_type

    request = Request(
        final_url,
        data=body,
        headers=request_headers,
        method=method,
    )
    try:
        with urlopen(request, timeout=timeout_sec) as response:
            return parse_json_response(response.read())
    except HTTPError as exc:
        payload = exc.read().decode("utf-8", errors="replace")
        raise TreefyitToolError(
            f"TreefyIt request failed: {exc.code} {exc.reason}; body={payload[:400]}"
        ) from exc
    except URLError as exc:
        raise TreefyitToolError(f"TreefyIt request failed: {exc.reason}") from exc


def encode_multipart_formdata(
    *,
    file_field: str,
    file_name: str,
    file_content: bytes,
    extra_fields: dict[str, str],
) -> tuple[bytes, str]:
    boundary = "treefyit-skill-boundary"
    lines: list[bytes] = []

    for key, value in extra_fields.items():
        lines.extend(
            [
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode(),
                value.encode(),
                b"\r\n",
            ]
        )

    lines.extend(
        [
            f"--{boundary}\r\n".encode(),
            (
                f'Content-Disposition: form-data; name="{file_field}"; '
                f'filename="{file_name}"\r\n'
            ).encode(),
            b"Content-Type: application/octet-stream\r\n\r\n",
            file_content,
            b"\r\n",
            f"--{boundary}--\r\n".encode(),
        ]
    )
    return b"".join(lines), f"multipart/form-data; boundary={boundary}"


@dataclass
class TreefyitClient:
    base_url: str | None = None
    api_key: str | None = None
    timeout_sec: float = 60.0

    def __post_init__(self) -> None:
        self.base_url = resolved_base_url_from_all_sources(self.base_url)
        self.api_key = resolve_api_key(self.api_key)

    def auth_headers(self) -> dict[str, str]:
        if not self.api_key:
            return {}
        return {"Authorization": f"Bearer {self.api_key}"}

    def build_knowledge(
        self, file: str | Path, *, summarize: bool = True
    ) -> dict[str, Any]:
        file_path = Path(file)
        if not file_path.exists():
            raise FileNotFoundError(file_path)
        if not file_path.is_file():
            raise TreefyitToolError(f"Expected a file path, got: {file_path}")

        payload, content_type = encode_multipart_formdata(
            file_field="file",
            file_name=file_path.name,
            file_content=file_path.read_bytes(),
            extra_fields={"summarize": str(summarize).lower()},
        )
        return request_json(
            "POST",
            f"{self.base_url}/api/build",
            timeout_sec=self.timeout_sec,
            headers=self.auth_headers(),
            body=payload,
            content_type=content_type,
        )

    def overview_forest(self) -> dict[str, Any]:
        return request_json(
            "GET",
            f"{self.base_url}/api/forest",
            timeout_sec=self.timeout_sec,
            headers=self.auth_headers(),
        )

    def search_trees(self, query: str, *, limit: int = 5) -> list[dict[str, Any]]:
        if not query.strip():
            return []

        return request_json(
            "GET",
            f"{self.base_url}/api/forest/search/trees",
            params={"q": query, "limit": limit},
            timeout_sec=self.timeout_sec,
            headers=self.auth_headers(),
        )

    def overview(self, tree_id: str) -> dict[str, Any]:
        return request_json(
            "GET",
            f"{self.base_url}/api/trees/{tree_id}",
            timeout_sec=self.timeout_sec,
            headers=self.auth_headers(),
        )

    def children(self, tree_id: str, node_id: str = "0") -> dict[str, Any]:
        return request_json(
            "GET",
            f"{self.base_url}/api/trees/{tree_id}/children/{node_id}",
            timeout_sec=self.timeout_sec,
            headers=self.auth_headers(),
        )

    def inspect(self, tree_id: str, node_id: str = "0") -> dict[str, Any]:
        return request_json(
            "GET",
            f"{self.base_url}/api/trees/{tree_id}/nodes/{node_id}",
            timeout_sec=self.timeout_sec,
            headers=self.auth_headers(),
        )


__all__ = [
    "BASE_URL_ENV",
    "API_KEY_ENV",
    "CONFIG_FILE_NAME",
    "CONFIG_PATH_ENV",
    "DEFAULT_BASE_URL",
    "TreefyitClient",
    "TreefyitToolError",
    "default_config_path",
    "load_config",
]
